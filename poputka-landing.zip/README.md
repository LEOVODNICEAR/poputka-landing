# Poputka Landing (GitHub Pages)
Acest repo public servește domeniul `poputka.md` prin GitHub Pages.

## Pași
1. Activați **Settings → Pages**: Source `Deploy from a branch`, Branch `main` și `/ (root)`.
2. Lăsați fișierul `CNAME` cu `poputka.md` la rădăcină.
3. Editați `index.html` după nevoie.
